# SIMPLE landing page

SIMPLE is a clean, responsive html landing page for general use.

![img](assets/img/screenshot.jpg)

**Demo** <https://jgmuchiri.github.io/simple-html-landing-page/>
